how to
======

0. install nodejs and python
1. create a virtualenv and activate it
2. run `pip install -r requirements.txt`
3. create a folder called ts
4. run `find . | grep json | node people.js '<your fb name>'`
5. run `python analysis-culm.py ts/*` (or pick only some particular files)
6. try the other python scripts
